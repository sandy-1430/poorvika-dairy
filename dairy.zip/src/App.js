import "./App.css";
import "bootstrap/dist/css/bootstrap.min.css";
import Header from "./components/header";
import Home from "./screens/Home";
import Footer from "./components/footer";
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>;

function App() {
  return (
    <div className="App">
      <Header />
      <Home></Home>
      <Footer></Footer>
    </div>
  );
}

export default App;
